function [H LM1 LM2] = getdata

load data.mat

M1 = gene_expression_data;
M2 = drug_response_data;
W1 = gene_gene_interaction;
W2 = drug_drug_interaction;

n1 = size(M1, 2);
n2 = size(M2, 2);

%standardized
M1 = zscore(M1);
M2 = zscore(M2);

H = zeros(n1, n2);
for i = 1 : n1
	for j = 1 : n2
		H(i, j) = calculateDis(M1(:, i), M2(:, j));
	end
end

%calculate LM1
diagD1 = sum(W1, 2);
D1 = sparse(n1, n1, 0);
for i = 1 : n1
	D1(i, i) = diagD1(i);
end

D1(find(D1 ~= 0)) = 1./sqrt(D1(find(D1 ~= 0)));
LM1 =  - D1 * W1 * D1;
for i = 1 : n1
	LM1(i, i) = (1 + 1e-10);
	%LM1(i, i) = 1;
end

%calculate LM2
diagD2 = sum(W2, 2);
D2 = sparse(98, 98, 0);
for i = 1 :98 
	D2(i, i) = diagD2(i);
end

D2(find(D2 ~= 0)) = 1./sqrt(D2(find(D2 ~= 0)));
LM2 =  - D2 * W2 * D2;
for i = 1 : 98 
	LM2(i, i) = (1 + 1e-10);
	%LM2(i, i) = 1;
end
