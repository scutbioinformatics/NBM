%------------------------------------------------------------------------------------------------------------------------ 
function X_next = lagrangian_multiplier_v7(H, LM1, LM2, parameters);
	[n1 n2] = size(H);
	I1 = ones(n2, 1);
	I2 = ones(n1, 1);
	b1 = parameters.c1 * ones(n1, 1);
	b2 = parameters.c2 * ones(n2, 1);
	beta = parameters.beta;
	lambda = [parameters.lambda1 parameters.lambda2];
	H = 10 * H;
	M = 10;										%punish coefficient 
	factor_of_next_M = 2;						
	descend_rate = 0.5;							
	precision = 1e-6 * n1 * n2;				
	max_iter = 200;						
	iter = 0;
	numsOfInequal = n1 + n2 + 2 * n1 * n2;
	multiplier =  ones(n1 + n2 + 2 * n1 * n2, 1);


	X_next = zeros(size(H));
	X_now = X_next;
	g_now = values_of_constrains(X_now, n1, n2, I1, I2, b1, b2);
	flag_next = compare(g_now, n1, n2, I1, I2, b1, b2, multiplier, M);
	while iter < max_iter
		disp('begin iter');
		tic
		iter = iter + 1
		X_now = X_next;
		flag_now = flag_next;

		X_next = gradient_descend(X_now, X_next, g_now, H, LM1, LM2, lambda, I1, I2, b1, b2, beta, multiplier, M);

		g_next = values_of_constrains(X_next, n1, n2, I1, I2, b1, b2);

		flag_next = compare(g_next, n1, n2, I1, I2, b1, b2, multiplier, M);

		if flag_next < precision 
			disp('answer is under the precision');
			break;
		end

		if flag_next >= descend_rate * flag_now
			M = min(1e4, factor_of_next_M * M)
		end
		

		multiplier = min(0, multiplier - M * g_next);
		toc
		disp('end iter');

	end
	%show the result
	figure(1);
	MIN = min(min(X_next));
	MAX = max(max(X_next));
	X_next = (X_next - MIN) / (MAX - MIN);
	imagesc(X_next);
    figure;
    imagesc(X_next > 2 * graythresh(X_next));

end



%-----------------------------------------------------------------------------------------
function X_next = gradient_descend(X_now, X_next, g_now, H, LM1, LM2, lambda, I1, I2, b1, b2, beta, multiplier, M)
	[n1 n2] = size(H);
	MAX_ITER = 200;
	stepSize = 1e-2;
	factor_of_next_stepSize = 0.1;
	ABSTOL = 1e-4;
	delta = 0;
	optval_next = objective_funcition_and_constrains(X_now, H, LM1, LM2, lambda, I1, I2, b1, b2, beta, multiplier, M);
	for k = 1 : MAX_ITER		
		X_now = X_next;
		optval_now = optval_next;

		grad_X_now = Gradient(X_now, H, LM1, LM2, lambda, I1, I2, b1, b2, beta, multiplier, M);


		while 1
			X_next = X_now - stepSize * grad_X_now;
			optval_next = objective_funcition_and_constrains(X_next, H, LM1, LM2, lambda, I1, I2, b1, b2, beta, multiplier, M);
			if optval_next < (optval_now + delta) || stepSize < 1e-5
				break;
			end
			stepSize = factor_of_next_stepSize * stepSize;
		end

		if k > 1 && abs(optval_next - optval_now) < ABSTOL
			break;
		end
	end
end




%-----------------------------------------------------------------------------------------

function grad_X = Gradient(X, H, LM1, LM2, lambda, I1, I2, b1, b2, beta, multiplier, M)
	[n1 n2] = size(X);
	U = ones(n1, n2);
	grad_X   = H + lambda(1) * (LM1 + LM1') * X + lambda(2) * X * (LM2 + LM2') + beta * U + repmat(max(-multiplier(1 : n1) + M * (X * I1 - b1), 0), 1, n2) + repmat(max(-multiplier(n1 + 1 : n1 + n2) + M * (X' * I2 - b2), 0)', n1, 1) - max(- reshape(multiplier(n1 + n2 + 1 : n1 + n2 + n1 * n2), n1, n2) - M * X, 0) + max(- reshape(multiplier(n1 + n2 + n1 * n2 + 1 : n1 + n2 + 2 * n1 * n2), n1, n2) + M * (X - 1), 0);	
end



%-----------------------------------------------------------------------------------------
function SUM = compare(g, n1, n2, I1, I2, b1, b2, multiplier, M)

	SUM = sqrt(sum((max(g, multiplier / M)) .^ 2));

end

%-----------------------------------------------------------------------------------------
function g = values_of_constrains(X, n1, n2, I1, I2, b1, b2)

	g = zeros(n1 + n2 + 2 * n1 * n2, 1);

	%XI1 <= b1
	g(1 : n1) = X * I1 - b1;


	%X'I2 <= b2
	g(n1 + 1 : n1 + n2) = X' * I2 - b2;

	%0 < X
	bias1 = n1 + n2;
	for j = 1 : n2
		g(bias1 + 1 + (j - 1) * n1  : bias1 + j * n1) = -X(:, j);
	end


	%X < U
	bias2 = n1 + n2 + n1 * n2;
	g(bias2 + 1 : bias2 + n1 * n2) = -g(bias1 + 1 : bias1 + n1 * n2) - 1;


end

	
%-----------------------------------------------------------------------------------------
%tr(H'X) + lambda(1) * tr(X'LM1X) + lambda(2) * tr(XLM2X') + beta * tr(U'X)
%XI1 <= b1		X'I2 <= b2		0 < X < U
function f = objective_funcition_and_constrains(X, H, LM1, LM2,lambda, I1, I2, b1, b2, beta, multiplier, M)

	[n1 n2] = size(H);
	numsOfInequal = n1 + n2 + 2 * n1 * n2;
	g = values_of_constrains(X, n1, n2, I1, I2, b1, b2);
	
	inequal_sum = 0;

	inequal_sum = sum((0.5 / M) * (max(0, (-multiplier + M * g)) .^2 - multiplier.^2));

	f = objective_function(X, H, LM1, LM2,lambda, beta) + inequal_sum;
end



%-----------------------------------------------------------------------------------------
%tr(H'X) + lambda(1) * tr(X'LM1X) + lambda(2) * tr(XLM2X') + beta * tr(U'X)
function f = objective_function(X, H, LM1, LM2,lambda, beta)
	U = ones(size(H));
	f = trace(H' * X) + lambda(1) * trace(X' * LM1 * X) + lambda(2) * trace(X * LM2 * X') + beta * trace(U' * X);
end

