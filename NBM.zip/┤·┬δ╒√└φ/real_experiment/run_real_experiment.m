clc;
clear;

parameters = setting_parameter;
[H LM1 LM2] = getdata;
X = NBM(H, LM1, LM2, parameters);
