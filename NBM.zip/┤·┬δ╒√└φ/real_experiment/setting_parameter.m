function parameters = setting_parameter
%this function is used for parameters setting

parameters.c1 =	3;								%the maximun drug number that a gene relate to
parameters.c2 = 100;							%the maximun gene number that a drug relate to
parameters.lambda1 = 100;						%the parameter of %tr(X' * L_{M_{1}} * X)
parameters.lambda2 = 100;						%the parameter of %tr(X * L_{M_{2}} * X')
parameters.beta = 0.9;							%the parameter of ||x||_1
