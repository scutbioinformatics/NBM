function parameters = setting_parameter
%this function is used for parameters setting


parameters.n1 = 400;								%number of genes
parameters.n2 = 100;								%number of drugs
parameters.sizeOfSample = 100;						%number of samples    
parameters.c1 = ceil(parameters.n2 / 2);						%the maximun drug number that a gene relate to
parameters.c2 = ceil(parameters.n1 / 8);						%the maximun gene number that a drug relate to
%parameters.k1 = ceil(parameters.n2 / 2);						%
%parameters.k2 = ceil(parameters.n1 / 8);						%
parameters.K1 = ceil(parameters.n1 / 8);						%used in the constructiong of L_{M_{1}}
parameters.K2 = ceil(parameters.n2 / 2);						%used in the constructiong of L_{M_{2}}
parameters.lambda1 = 100 / 17;							%the parameter of %tr(X' * L_{M_{1}} * X)
parameters.lambda2 = 100 / 17;							%the parameter of %tr(X * L_{M_{2}} * X')
parameters.sigma_x = 1;							%noise level, range from 1 to 3
parameters.beta = 1 / 17;								%the parameter of ||x||_1
