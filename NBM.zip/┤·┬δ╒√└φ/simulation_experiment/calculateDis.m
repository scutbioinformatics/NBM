function dis = calculateDis(vec1, vec2)
%v1 =vec1 - mean(vec1);
%v2 =vec2 - mean(vec2);
%dis = - abs( v1'*v2 / (sqrt(v1' * v1) * sqrt(v2' * v2)) );

dis = norm(vec1 - vec2);
