function [M1 M2 H LM1 LM2] = data_simulation(parameters)

sizeOfSample1_1 = fix(parameters.sizeOfSample * 1 / 4);	%25
sizeOfSample1_2 = fix(parameters.sizeOfSample * 2 / 4);	%50
sizeOfSample1_3 = fix(parameters.sizeOfSample * 3 / 4);	%75
sizeOfSample1_4 = fix(parameters.sizeOfSample * 4 / 4);	%100

%simulate l1 ~ l6
l1 = zeros(parameters.sizeOfSample, 1);
l1(1 : sizeOfSample1_2) = 3;
l1(sizeOfSample1_2 + 1 : parameters.sizeOfSample) = 4;
l2 = zeros(parameters.sizeOfSample, 1);
l2(1 : sizeOfSample1_1) = 2.5;
l2(sizeOfSample1_1 + 1 : sizeOfSample1_2) = 4;
l2(sizeOfSample1_2 + 1 : sizeOfSample1_3) = 2.5;
l2(sizeOfSample1_3 + 1 : sizeOfSample1_4) = 4;
l_3 = rand(parameters.sizeOfSample, 1);
l3 = 3.5 + 1.5 * (l_3 < 0.4);
l_4 = rand(parameters.sizeOfSample, 1);
l4 = 3.5 + 0.5 * (l_4 < 0.7);
l_5 = rand(parameters.sizeOfSample, 1);
l5 = 3.5 - 1.5 * (l_5 < 0.3);
l6 = 3.5 * ones(parameters.sizeOfSample, 1);

%simulate M1
n1_01 = fix(parameters.n1 * 1 / 40);	%10
n1_02 = fix(parameters.n1 * 2 / 40);	%20
n1_03 = fix(parameters.n1 * 3 / 40);	%30
n1_04 = fix(parameters.n1 * 4 / 40);	%40
n1_05 = fix(parameters.n1 * 5 / 40);	%50

n1_1 = fix(parameters.n1 * 1 / 16);	%25
n1_2 = fix(parameters.n1 * 2 / 16);	%50
n1_3 = fix(parameters.n1 * 4 / 16);	%100
n1_4 = fix(parameters.n1 * 8 / 16);	%200
n1_5 = fix(parameters.n1 * 12 / 16);	%300
n1_6 = fix(parameters.n1 * 16 / 16);	%300

X0 = zeros(parameters.sizeOfSample, parameters.n1);
X0(:, 1 : n1_01) = repmat(l1, 1, n1_01); 

SIGMA = sqrt(1 - 0.9 * 0.9);
tmpSize = n1_05 - n1_01;
for j = 1 : tmpSize
	X0(:, n1_01 + j) = normrnd(0.9 * X0(:, j), SIGMA);
end
X0(:, n1_2 + 1: n1_3) = repmat(l3, 1, n1_3 - n1_2); 
X0(:, n1_3 + 1: n1_4) = repmat(l4, 1, n1_4 - n1_3); 
X0(:, n1_4 + 1: n1_5) = repmat(l5, 1, n1_5 - n1_4); 
X0(:, n1_5 + 1: n1_6) = repmat(l6, 1, n1_6 - n1_5);
X = X0 + parameters.sigma_x * randn(parameters.sizeOfSample, parameters.n1);

%simulate Y
b1 = zeros(parameters.n1, 1);
b1(1 : n1_01) = 8 / n1_1;
b1(n1_01 + 1 : n1_02) = 6 / n1_1;
b1(n1_02 + 1 : n1_03) = 4 / n1_1;
b1(n1_03 + 1 : n1_04) = 2 / n1_1;
b1(n1_04 + 1 : n1_05) = 1 / n1_1;
b1(n1_05 + 1 : n1_6) = 0;
b2 = randn(parameters.n1, 1) ./ n1_02;
B = zeros(parameters.n1, parameters.n2);
n2_1 = fix(parameters.n1 * 1 / 16);		%25
n2_2 = fix(parameters.n1 * 2 / 16);		%50
n2_3 = fix(parameters.n1 * 4 / 16);		%100
B(:, 1 : n2_1) = repmat(b1, 1, n2_1);
B(:, n2_1 + 1: n2_2) = repmat(-b1, 1, n2_2 - n2_1);
B(:, n2_2 + 1: n2_3) = repmat(b2, 1, n2_3 - n2_2);
XB = X * B;
sigma_y =  parameters.sigma_x * (parameters.n1  / parameters.n2) * (norm(XB, 'fro') / norm(X0, 'fro'));
Y = XB + sigma_y * randn(parameters.sizeOfSample, parameters.n2);

%normalize
X = zscore(X);
Y = zscore(Y);

%get M1, M2
M1 = X;
M2 = Y;


%get the distance matrix
H = zeros(parameters.n1, parameters.n2);
for i = 1 : parameters.n1
	for j = 1 : parameters.n2
		H(i, j) = calculateDis(M1(:, i), M2(:, j));
	end
end


rate = 0.8;
%simulate W1
W1 = randn(parameters.n1, parameters.n1) < 0.1;
W1(1 : parameters.K1, 1 : parameters.K1) = randn(parameters.K1, parameters.K1) < rate;
W1 = tril(W1);
W1 = W1 + W1';
for i = 1 : parameters.n1 
	W1(i, i) = 0;
end

%calculate D1
diagD1 = sum(W1, 2);
D1 = sparse(parameters.n1, parameters.n1, 0);
for i = 1 : parameters.n1
	D1(i, i) = diagD1(i);
end


%get standardized LM1
D1(find(D1 ~= 0)) = 1./sqrt(D1(find(D1 ~= 0)));
LM1 =  - D1 * W1 * D1;
for i = 1 : parameters.n1
	LM1(i, i) = (1 + 1e-10);
end

%simulate W2
W2 = randn(parameters.n2, parameters.n2) < 0.1;
W2(1 : parameters.K2, 1 : parameters.K2) = randn(parameters.K2, parameters.K2) < rate;
W2 = tril(W2);
W2 = W2 + W2';
for i = 1 : parameters.n2 
	W2(i, i) = 0;
end


%calculate D2
diagD2 = sum(W2, 2);
D2 = sparse(parameters.n2, parameters.n2, 0);
for i = 1 : parameters.n2
	D2(i, i) = diagD2(i);
end


%get standardized LM2
D2(find(D2 ~= 0)) = 1./sqrt(D2(find(D2 ~= 0)));
LM2 =  - D2 * W2 * D2;
for i = 1 : parameters.n2
	LM2(i, i) = (1 + 1e-10);
end









