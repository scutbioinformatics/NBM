clc;
clear;

parameters = setting_parameter;
[M1 M2 H LM1 LM2] = data_simulation(parameters);
[X FPR TPR AUC] = NBM(H, LM1, LM2, parameters);


